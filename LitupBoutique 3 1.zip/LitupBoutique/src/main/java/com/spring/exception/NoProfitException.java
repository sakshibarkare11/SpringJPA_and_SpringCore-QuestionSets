package com.spring.exception;

public class NoProfitException extends Exception {

	public NoProfitException(String msg) {
		// Fill the code
		super(msg);
	}
}
