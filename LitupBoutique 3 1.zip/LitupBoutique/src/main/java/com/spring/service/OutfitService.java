package com.spring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.spring.bo.OutfitBO;
import com.spring.exception.NoProfitException;
import com.spring.model.Outfit;

//use appropriate annotation to make this class as component class
@Component
public class OutfitService {

	private OutfitBO outfitBO;

//use appropriate annotation 
    @Autowired
	public OutfitService(OutfitBO outfitBO) {
		super();
		this.outfitBO = outfitBO;
	}

	public OutfitBO getOutfitBO() {
		return outfitBO;
	}

	public void setOutfitBO(OutfitBO outfitBO) {
		this.outfitBO = outfitBO;
	}

	public void calculateNetProfit(Outfit outfitObj) throws NoProfitException {
		
		
		double netProfit=outfitBO.calculateNetProfit(outfitObj);
		if(netProfit<=0)
		{
			throw new NoProfitException("No profit to calculate the prize money");
		}
		outfitObj.calculatePrizeMoney(netProfit);
		// Fill the code

	}
}