package com.spring.model;

public interface OutfitDesigner {
	  
  void calculatePrizeMoney(double netProfit);
 
}
