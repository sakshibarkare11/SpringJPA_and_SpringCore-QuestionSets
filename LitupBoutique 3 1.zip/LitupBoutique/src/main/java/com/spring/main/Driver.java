package com.spring.main;

import java.util.ArrayList;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.spring.config.ApplicationConfig;
import com.spring.exception.NoProfitException;
import com.spring.model.Outfit;
import com.spring.service.OutfitService;

public class Driver {

	public static void main(String[] args) {
		// Fill the code
		ApplicationContext applicationContext=new AnnotationConfigApplicationContext(ApplicationConfig.class);
		Scanner sc=new Scanner(System.in);
		
		ArrayList< String> arrayList=new ArrayList<String>();
		for(int i=1;i<3;i++)
		{
			System.out.println("Outfit "+i+" details");
			System.out.println("Enter the total income");
			double income=sc.nextDouble();
			System.out.println("Enter the salary of the designer");
			double salary=sc.nextDouble();
			Outfit outfit=  applicationContext.getBean(Outfit.class);
			outfit.setTotalIncome(income);
			outfit.setDesignerSalary(salary);
			OutfitService outfitService=applicationContext.getBean(OutfitService.class);
			try {
				outfitService.calculateNetProfit(outfit);
				arrayList.add("The prize money for outfit "+i+" is $"+outfit.getPrizeMoney());
				
			}
			catch (NoProfitException e) {
				arrayList.add(e.getMessage());
				
			}
		}
		for(String value:arrayList)
		{
			System.out.println(value);
		}
			
	}

}
