package com.spring.bo;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.spring.model.Outfit;

//use appropriate annotation to make this class as component class
@Component
public class OutfitBO {

	public double calculateNetProfit(Outfit outfitObj) {
		double netProfit = 0;
		// fill he code
		double expenses=outfitObj.getDesignerSalary();
		for(Map.Entry<String, Double> item:outfitObj.getOutfitExpenses().entrySet())
		{
			expenses=expenses+item.getValue();
		}
		netProfit=outfitObj.getTotalIncome()-expenses;
		return netProfit;
	}
}
