package com.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.entities.Restaurant;
import com.exception.InvalidRestaurantException;
import com.repository.RestaurantRepository;
@Component
public class RestaurantDAOImpl implements IRestaurantDAO {
    
	// Provide necessary Annotation
	@Autowired
	private RestaurantRepository restaurantRepository;

	public Restaurant addRestaurant(Restaurant restaurant) {
			// fill code
		return restaurantRepository.save(restaurant);
	}

	public Restaurant viewRestaurantById(int restaurantId) throws InvalidRestaurantException {
			// fill code
		Optional<Restaurant> byId = restaurantRepository.findById(restaurantId);
		if(byId.isPresent()) {
			Restaurant obj = byId.get();
			return obj;
		}
		else {
			throw new InvalidRestaurantException();
		}
	}
	
	

	public Restaurant updateRestaurantRating(int restaurantId, double rating) throws InvalidRestaurantException{
	    	// fill code
		Optional<Restaurant> byId = restaurantRepository.findById(restaurantId);
		if(byId.isPresent()) {
			Restaurant obj = byId.get();
			obj.setRating(rating);
			return restaurantRepository.save(obj);
		}
		else {
			throw new InvalidRestaurantException();
		}
	}


	public List<Restaurant> viewRestaurantsByRatingAndLocation(double rating, String location) {
		// fill code
		
		return restaurantRepository.findByRatingGreaterAndLocation(rating, location);
		
	}


	public Map<Integer, Integer> getOrderCountRestaurantWise() {
	    	// fill code
		
		  List<Object[]> objectObj = restaurantRepository.findCountByRestaurantWise();
		  Map<Integer,Integer> map = new HashMap<>();
		  for(Object[] object : objectObj) {
			  int id = (int) object[0];
			  int count = (int) object[1];
			  map.put(id, count);
		  }
		
		return map;
	}


	
}
