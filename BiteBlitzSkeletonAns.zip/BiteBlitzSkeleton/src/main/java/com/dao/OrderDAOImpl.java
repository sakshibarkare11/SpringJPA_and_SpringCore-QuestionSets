package com.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.entities.Restaurant;
import com.entities.Orders;
import com.exception.InvalidOrderException;
import com.exception.InvalidRestaurantException;
import com.repository.RestaurantRepository;

import com.repository.OrderRepository;

@Component
public class OrderDAOImpl implements IOrderDAO {
	
	// Provide necessary Annotation
	@Autowired
	private OrderRepository orderRepository;
	
	//Provide necessary Annotation
	@Autowired
	private RestaurantRepository restaurantRepository;

	public Orders addOrder(Orders order, int restaurantId) throws InvalidRestaurantException {
	// fill code
		Optional<Restaurant> byId = restaurantRepository.findById(restaurantId);
		if(byId.isPresent()) {
			Restaurant obj = byId.get();
			order.setRestaurantObj(obj);
			return orderRepository.save(order);
		}
		else {
			throw new InvalidRestaurantException();
		}
		
	}
	
	public Orders updatePaymentMethod(int orderId, String paymentMethod) throws InvalidOrderException {
	    // fill code
		Optional<Orders> byId = orderRepository.findById(orderId);
		if(byId.isPresent()) {
			Orders obj = byId.get();
			obj.setPaymentMethod(paymentMethod);
			return orderRepository.save(obj);
		}
		else {
			throw new InvalidOrderException();
		}
	}


	public List<Orders> viewOrdersByStatus(String status) {
		// fill code
		return orderRepository.findByStatus(status);
		
	}


	public List<Orders> viewOrdersByRestaurantName(String restaurantName) {
		// fill code
		return orderRepository.findByRestaurantName(restaurantName);
	}

    public Orders cancelOrder(int orderId) throws InvalidOrderException {
       	// fill code
    	Optional<Orders> byId = orderRepository.findById(orderId);
    	if(byId.isPresent()) {
    		Orders obj = byId.get();
    		orderRepository.delete(obj);
    		return obj;
    	}
    	else {
    		throw new InvalidOrderException();
    	}
    }
}
