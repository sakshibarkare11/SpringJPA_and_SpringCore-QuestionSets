package com.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.entities.Restaurant;

//Provide necessary annotation

public interface RestaurantRepository extends JpaRepository<Restaurant, Integer>{

	@Query(value="select * from Restaurant r where r.rating >= ?1 and r.location = ?2", nativeQuery = true)
	List<Restaurant> findByRatingGreaterAndLocation(double rating, String location);

	@Query(value = "select r.restaurant_id, count(o.order_id) from Restaurant r left join Order o using(restaurant_id)", nativeQuery = true)
	List<Object[]> findCountByRestaurantWise();
    
	//Integer findByRestaurantName(String restaurantName);
    // Provide necessary methods to view restaurants by rating and location, and to get order count restaurant wise
	
}
