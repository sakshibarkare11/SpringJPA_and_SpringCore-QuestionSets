package com.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.entities.Orders;

//Provide necessary annotation
 
public interface OrderRepository extends JpaRepository<Orders, Integer>{

	@Query(value = "select * from Orders o where o.status=?1", nativeQuery = true)
	List<Orders> findByStatus(String status);

	@Query(value = "select * from Orders o left join restaurant r using(restaurant_id) where r.restaurant_name=restaurant_name", nativeQuery = true)
	//@Query("select o from Orders o where o.restaurantObj.restaurantName= ?1")
	List<Orders> findByRestaurantName(String restaurantName);
    
    // Provider necessary methods to view orders by status and view orders by the
	// given restaurant name
	

}
