package com.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.entities.Restaurant;
import com.exception.InvalidRestaurantException;
import com.service.IRestaurantService;

import jakarta.validation.Valid;

//Provide necessary Annotation
@RestController
public class RestaurantController {

//Provide necessary Annotation
	@Autowired
	private IRestaurantService restaurantService;
	
	// Provide necessary Annotation for the below methods and fill the code
	@PostMapping("/addRestaurant")
	public Restaurant addRestaurant(@Valid @RequestBody Restaurant restaurant) {
		return restaurantService.addRestaurant(restaurant);
	}

	@GetMapping("/viewRestaurantById/{restaurantId}")
	public Restaurant viewRestaurantById(@PathVariable int restaurantId) throws InvalidRestaurantException {
		return restaurantService.viewRestaurantById(restaurantId);
	}
	
	@PutMapping("/updateRestaurantRating/{restaurantId}/{rating}")
    public Restaurant updateRestaurantRating(@PathVariable int restaurantId,@PathVariable double rating) throws InvalidRestaurantException  {
		return restaurantService.updateRestaurantRating(restaurantId, rating);
	}
	
	@GetMapping("/viewRestaurantsByRatingAndLocation/{rating}/{location}")
    public List<Restaurant> viewRestaurantsByRatingAndLocation(@PathVariable double rating,@PathVariable String location) {	 	  	      	 	    	      	    	      	 	
		return restaurantService.viewRestaurantsByRatingAndLocation(rating, location);

	}
	
    @GetMapping("/getOrderCountRestaurantWise")
    public Map<Integer,Integer> getOrderCountRestaurantWise() {
		return restaurantService.getOrderCountRestaurantWise();
	}

}
