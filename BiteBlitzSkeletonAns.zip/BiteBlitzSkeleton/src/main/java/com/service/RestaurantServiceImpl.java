package com.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.IRestaurantDAO;
import com.entities.Restaurant;
import com.exception.InvalidRestaurantException;

//Provide necessary annotation
@Service
public class RestaurantServiceImpl implements IRestaurantService {
	
	// Provide necessary annotation
	@Autowired
	private IRestaurantDAO restaurantDAO; 

	public Restaurant addRestaurant(Restaurant restaurant) {
		// fill the code
		return restaurantDAO.addRestaurant(restaurant);
	}

	public Restaurant viewRestaurantById(int restaurantId) throws InvalidRestaurantException {
		// fill the code
		return restaurantDAO.viewRestaurantById(restaurantId);
	}


	public Restaurant updateRestaurantRating(int restaurantId, double rating) throws InvalidRestaurantException{
	    // fill the code
		return restaurantDAO.updateRestaurantRating(restaurantId, rating);
	}


	public List<Restaurant> viewRestaurantsByRatingAndLocation(double rating, String location) {
	    // fill the code
		return restaurantDAO.viewRestaurantsByRatingAndLocation(rating, location);
	
	}


	public Map<Integer, Integer> getOrderCountRestaurantWise() {
	    // fill the code
		return restaurantDAO.getOrderCountRestaurantWise();
	
	}
}
