package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.IOrderDAO;
import com.entities.Orders;
import com.exception.InvalidOrderException;
import com.exception.InvalidRestaurantException;

// Provide necessary annotation
@Service
public class OrderServiceImpl implements IOrderService{
	
    // Provide necessary annotation
	@Autowired
	private IOrderDAO orderDAO;

	public Orders addOrder(Orders order, int restaurantId) throws InvalidRestaurantException {
		// fill the code
		return orderDAO.addOrder(order, restaurantId);
	}

	public Orders updatePaymentMethod(int orderId, String paymentMethod) throws InvalidOrderException {
	// fill the code
		return orderDAO.updatePaymentMethod(orderId, paymentMethod);
	}

	public List<Orders> viewOrdersByStatus(String status) {
		// fill the code
		return orderDAO.viewOrdersByStatus(status);
	}


	public List<Orders> viewOrdersByRestaurantName(String restaurantName) {
		// fill the code
		return orderDAO.viewOrdersByRestaurantName(restaurantName);
	}

	public Orders cancelOrder(int orderId) throws InvalidOrderException {
		// fill the code
		return orderDAO.cancelOrder(orderId);
	}

}
