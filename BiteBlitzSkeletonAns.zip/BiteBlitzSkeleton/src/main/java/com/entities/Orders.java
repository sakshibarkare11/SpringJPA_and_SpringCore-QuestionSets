package com.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Data;

//Provide necessary Annotation wherever necessary
@Entity
@Data
@AllArgsConstructor
public class Orders {
	
    //Provide necessary Annotation 
    @Id
    @Min(value = 1,message = "sadfd")
	private int orderId;
    @NotEmpty(message = "sdadd")
	private String deliveryAddress;
    @NotEmpty(message = "oijjb")
	private String paymentMethod;
    @NotEmpty(message = "mncsd")
	private String status;
    @Min(value=1, message="123456")
	private double totalAmount;
	
    //Provide necessary Annotation 
    @ManyToOne
    @JoinColumn(name = "restaurant_id")
    @JsonIgnore
	private Restaurant restaurantObj;
	
	public Orders() {
		super();
	}
	
}
