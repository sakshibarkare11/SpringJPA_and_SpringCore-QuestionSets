package com.entities;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Data;

//Provide necessary Annotation wherever necessary
@Entity
@Data
@AllArgsConstructor
public class Restaurant {
	
    //Provide necessary Annotation 
	@Id
	@Min(value = 1, message = "sdfdsff")
	private int restaurantId;
    @NotEmpty(message = "sdfgfhj")
	private String restaurantName;
    @NotEmpty(message = "sdfsfd")
	private String cuisine;
    
    @Min(value=1, message="123456")
    @Max(value=10,message="123456")
	private double rating;
    @NotEmpty(message = "scdsv")
	private String location;
	
    //Provide necessary Annotation 
    @OneToMany(mappedBy = "restaurantObj")
    @JsonIgnore
	private List<Orders> ordersList;
	
	public Restaurant() {
		super();
	}


}
