package com.exception;

public class InvalidOrderException extends Exception{

}
