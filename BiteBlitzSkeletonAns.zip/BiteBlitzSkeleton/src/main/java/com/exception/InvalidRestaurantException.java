package com.exception;

public class InvalidRestaurantException extends Exception{

}
