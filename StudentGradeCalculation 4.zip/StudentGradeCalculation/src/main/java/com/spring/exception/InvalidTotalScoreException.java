package com.spring.exception;

public class InvalidTotalScoreException extends Exception {

	public InvalidTotalScoreException(String msg) {
		// Fill the code
		super(msg);
	}
}
