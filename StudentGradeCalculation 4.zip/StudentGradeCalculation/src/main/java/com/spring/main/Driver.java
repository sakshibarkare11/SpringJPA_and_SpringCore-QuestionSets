package com.spring.main;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.spring.config.ApplicationConfig;
import com.spring.exception.InvalidTotalScoreException;
import com.spring.model.Student;
import com.spring.service.StudentService;

public class Driver {

	public static void main(String[] args) {
		
		ApplicationContext ctx =new AnnotationConfigApplicationContext(ApplicationConfig.class);
		
		StudentService service = ctx.getBean(StudentService.class);
		
		Scanner sc = new Scanner(System.in);
		// Fill the code
		
		List<String> list = new ArrayList<>();
		
			Student sem1 = ctx.getBean(Student.class);
			Student sem2 = ctx.getBean(Student.class);

			
			System.out.println("Semester 1 details");
			System.out.println("Enter the student id");
			String studId= sc.nextLine();
			System.out.println("Enter the stream");
			String stream= sc.nextLine();
			System.out.println("Enter the total score of the first semester");
			double totScore = Double.parseDouble(sc.nextLine());
			
			sem1.setStream(stream);
			sem1.setStudentId(studId);
			sem1.setTotalScore(totScore);
			
			try {
				service.calculateGradePoint(sem1);
				list.add("The credit score in the first semester is "+sem1.getCreditScore()+" points");
			} catch (InvalidTotalScoreException e) {
				list.add(e.getMessage());
			
			}
			
			
			
			System.out.println("Semester 2 details");
			System.out.println("Enter the student id");
			 studId= sc.nextLine();
			System.out.println("Enter the stream");
			 stream= sc.nextLine();
			System.out.println("Enter the total score of the second semester");
			totScore = Double.parseDouble(sc.nextLine());
			
			sem2.setStream(stream);
			sem2.setStudentId(studId);
			sem2.setTotalScore(totScore);
			
			try {
				service.calculateGradePoint(sem2);
				list.add("The credit score in the second semester is "+sem2.getCreditScore()+" points");
			} catch (InvalidTotalScoreException e) {
				list.add(e.getMessage());
			}
			
			
		
			list.forEach(System.out::println);
		
	}

}
