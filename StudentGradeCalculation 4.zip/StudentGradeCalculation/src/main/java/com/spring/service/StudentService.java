package com.spring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.spring.bo.StudentBO;
import com.spring.exception.InvalidTotalScoreException;
import com.spring.model.Student;

//use appropriate annotation to make this class as component class

@Component
@Scope("prototype")
public class StudentService {

	private StudentBO studentBO;

	// Use appropriate annotation
	@Autowired
	public StudentService(StudentBO studentBO) {
		super();
		this.studentBO = studentBO;
	}

	public StudentBO getStudentBO() {
		return studentBO;
	}

	public void setStudentBO(StudentBO studentBO) {
		this.studentBO = studentBO;
	}

	public void calculateGradePoint(Student studentObj) throws InvalidTotalScoreException {
		// Fill the code
		
		if(studentObj.getTotalScore()>400 || studentObj.getTotalScore()<100 )
		{
			throw new InvalidTotalScoreException("The total score should not be less than 0 or greater than 400");
		}
		
		studentObj.calculateCreditScore(studentBO.calculateGradePoint(studentObj));
		
		

	}
}
