package com.spring.model;

import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

//pojo class with required attributes,getters and setters 
//use appropriate annotation to make this class as component class
// Use appropriate annotation for scope

@Component
@Scope("prototype")
public class Student implements College {

	private String studentId;
	private String stream;
	private double totalScore;
	private double creditScore;

	// use appropriate annotation

	@Value("#{${streamDetails.map}}")
	private Map<String, Integer> streamDetails;

	// use appropriate annotation
	@Value("#{${percentage}}")
	private double percentage;

	public String getStudentId() {
		return studentId;
	}

	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}

	public String getStream() {
		return stream;
	}

	public void setStream(String stream) {
		this.stream = stream;
	}

	public double getTotalScore() {
		return totalScore;
	}

	public void setTotalScore(double totalScore) {
		this.totalScore = totalScore;
	}

	public double getCreditScore() {
		return creditScore;
	}

	public void setCreditScore(double creditScore) {
		this.creditScore = creditScore;
	}

	public Map<String, Integer> getStreamDetails() {
		return streamDetails;
	}

	public void setStreamDetails(Map<String, Integer> streamDetails) {
		this.streamDetails = streamDetails;
	}

	public double getPercentage() {
		return percentage;
	}

	public void setPercentage(double percentage) {
		this.percentage = percentage;
	}

	@Override
	public void calculateCreditScore(float gradePoint) {

		// fill the code
		creditScore =gradePoint * percentage;
		//System.out.println(creditScore);

	}
}
