package com.spring.model;

public interface College {
	  
 void calculateCreditScore(float gradePoint);
 
}
