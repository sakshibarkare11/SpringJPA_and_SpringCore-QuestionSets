package com.spring.bo;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.spring.model.Student;

//use appropriate annotation to make this class as component class
@Component
@Scope("prototype")
public class StudentBO {

	public float calculateGradePoint(Student studentObj) {
		float gradePoint = 0;

		// Fill the code
		
		int khalch =studentObj.getStreamDetails().get(studentObj.getStream());
		
		 gradePoint = (float) (studentObj.getTotalScore()/khalch);
		
		//System.out.println("Grade Point : "+gradePoint);
		

		return gradePoint;

	}
}
