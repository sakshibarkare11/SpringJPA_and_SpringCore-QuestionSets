package com.spring.exception;

public class UnavailableGameException extends Exception {

	String s;
	public UnavailableGameException(String msg) {
		// Fill the code here
		this.s = msg;
	}
}
