package com.spring.main;

import java.util.Scanner;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.spring.config.ApplicationConfig;
import com.spring.exception.UnavailableGameException;
import com.spring.model.Tournament;
import com.spring.service.TournamentService;

public class Driver {

	public static void main(String[] args) {
		// Fill the code
		
	}

}


//
