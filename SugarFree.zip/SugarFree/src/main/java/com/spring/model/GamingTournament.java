package com.spring.model;

public interface GamingTournament {

	void calculatePrizeMoney(double entryFeeRevenue) ;
}
