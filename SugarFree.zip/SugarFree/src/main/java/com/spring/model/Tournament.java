package com.spring.model;

import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

//pojo class with required attributes,getters and setters 
//use appropriate annotation to make this class as component class
// use appropriate annotation for scope

public class Tournament implements GamingTournament {

	private String gameName;//FIFA
	private int noOfParticipants;//10
	
	
	private double prizeMoney;

	// use appropriate annotation
	private Map<String, Double> gameDetails;

	// use appropriate annotation
	private double percentage;

	
    public Tournament() {
		super();
		
	}

	

	public String getGameName() {
		return gameName;
	}



	public void setGameName(String gameName) {
		this.gameName = gameName;
	}



	public int getNoOfParticipants() {
		return noOfParticipants;
	}



	public void setNoOfParticipants(int noOfParticipants) {
		this.noOfParticipants = noOfParticipants;
	}



	public double getPrizeMoney() {
		return prizeMoney;
	}



	public void setPrizeMoney(double prizeMoney) {
		this.prizeMoney = prizeMoney;
	}



	public Map<String, Double> getGameDetails() {
		return gameDetails;
	}



	public void setGameDetails(Map<String, Double> gameDetails) {
		this.gameDetails = gameDetails;
	}



	public double getPercentage() {
		return percentage;
	}



	public void setPercentage(double percentage) {
		this.percentage = percentage;
	}



	public void calculatePrizeMoney(double entryFeeRevenue) {
		// fill the code
		
		//this.setPrizeMoney(32455);
		
	}



	@Override
	public String toString() {
		return "Tournament [gameName=" + gameName + ", noOfParticipants=" + noOfParticipants + ", prizeMoney="
				+ prizeMoney + ", gameDetails=" + gameDetails + ", percentage=" + percentage + "]";
	}
}
