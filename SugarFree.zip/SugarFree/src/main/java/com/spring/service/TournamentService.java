package com.spring.service;

import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.spring.bo.TournamentBO;
import com.spring.exception.UnavailableGameException;
import com.spring.model.Tournament;

//use appropriate annotation to make this class as component class
public class TournamentService {

	private TournamentBO tournamentBO;

	//Use appropriate annotation
	
	public TournamentService(TournamentBO tournamentBO) {
		super();
		this.tournamentBO = tournamentBO;
	}

	public TournamentBO getTournamentBO() {
		return tournamentBO;
	}

	public void setTounamentBO(TournamentBO tournamentBO) {
		this.tournamentBO = tournamentBO;
	}

	public void calculateEntryFeeRevenue(Tournament tournamentObj) throws UnavailableGameException {
		
		//itrate over the map and get the value of that game 
		//fifa
		//map.get(tournamentObj.getgameName());
		// fill the code
		
		
		
	}
}