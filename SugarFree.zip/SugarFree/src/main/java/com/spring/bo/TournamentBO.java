package com.spring.bo;

import org.springframework.stereotype.Component;

import com.spring.model.Tournament;

//use appropriate annotation to make this class as component class
public class TournamentBO {

	public double calculateEntryFeeRevenue(Tournament tournamentObj) {
		double entryFeeRevenue = 0;
		// Fill the code here
		return entryFeeRevenue;
		
	}
}
