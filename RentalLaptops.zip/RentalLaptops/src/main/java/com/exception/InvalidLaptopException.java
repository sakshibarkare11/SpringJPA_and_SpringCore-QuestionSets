package com.exception;

public class InvalidLaptopException extends Exception {
    public InvalidLaptopException() {
		
	}
}
