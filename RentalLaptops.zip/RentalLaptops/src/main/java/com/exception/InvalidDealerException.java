package com.exception;

public class InvalidDealerException extends Exception {
    public InvalidDealerException() {
		
	}
}
