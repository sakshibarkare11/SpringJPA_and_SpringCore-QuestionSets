package com.exception;

public class InvalidLoanException extends Exception {
    public InvalidLoanException() {
		
	}
}
