package com.exception;

public class InvalidPaymentException extends Exception {
    public InvalidPaymentException() {
		
	}
}
