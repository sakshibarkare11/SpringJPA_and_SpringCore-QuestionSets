package com.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.*;

//Provide necessary Annotation
@Entity
@Getter
@Setter
@AllArgsConstructor
public class BankTransaction {

	//Provide necessary Annotation

	@Id
	private String transactionId;
	
	private String transactionDate;
	
	private String transactionType;//Deposit or Withdraw
	
	private double amount;
	
	@ManyToOne
	@JoinColumn(name="account_number")
	private Account accountObj;
	
	 public BankTransaction() {
        super();
    }
	
}
