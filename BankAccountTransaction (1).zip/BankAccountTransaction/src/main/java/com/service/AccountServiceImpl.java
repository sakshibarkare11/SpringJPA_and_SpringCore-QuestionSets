package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.IAccountDAO;
import com.entities.Account;

//Provide necessary Annotation
@Service
public class AccountServiceImpl implements IAccountService {
	
	
	//Provide necessary Annotation
	@Autowired
	IAccountDAO accountDAO;

	@Override
	public Account openAccount(Account account) {
		
		//fill code
		
		return accountDAO.openAccount(account);
	}
	
	@Override
	public Account viewAccountByAccountNumber(String accountNumber){

		//fill code
		
		return accountDAO.viewAccountByAccountNumber(accountNumber);		
	}

}
