import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Date;

public class MovieBookingSystem 
{
    public boolean validateCustomerDetails(String customerName, String bookingDate, String ticketType)  throws InvalidCustomerDetailsException,DateTimeParseException,ParseException
    {
	//fill the code here
    	if(!customerName.matches("[A-Z][A-Za-z]+")) {
    		throw  new InvalidCustomerDetailsException("Invalid customer name");
    	}
    	SimpleDateFormat sd=new SimpleDateFormat("yyyy-MM-dd");
    	try {
    	LocalDate ld=LocalDate.parse(bookingDate);
    	
    	}
    	catch(DateTimeParseException e){
    		throw new InvalidCustomerDetailsException("Invalid booking date");
    	}
    	
        if(!(ticketType.equalsIgnoreCase("standard")||ticketType.equalsIgnoreCase("premium"))) {
        	throw new InvalidCustomerDetailsException("Invalid ticket type");
        }
        return true;
    }

    public String getBookingConfirmation() 
    {
            String str="Your movie ticket is booked. Enjoy the show!";
           
          
           
	    //fill the code here
	    return str;
    }
}