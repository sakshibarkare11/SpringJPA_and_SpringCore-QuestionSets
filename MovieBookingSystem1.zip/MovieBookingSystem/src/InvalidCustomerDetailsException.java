
public class InvalidCustomerDetailsException extends Exception 
{
    public InvalidCustomerDetailsException(String message) 
    {
        super(message);
    }
}