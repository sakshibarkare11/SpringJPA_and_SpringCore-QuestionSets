import java.text.ParseException;
import java.util.Scanner;
public class UserInterface 
{
    public static void main(String[] args) throws ParseException 
    {
    	MovieBookingSystem m=new MovieBookingSystem();
        Scanner sc = new Scanner(System.in);
        //fill the code here
        System.out.println("Enter Customer Name");
        String name=sc.nextLine();
        System.out.println("Enter Booking Date");
        String date=sc.nextLine();
        System.out.println("Enter Ticket Type");
        String type=sc.nextLine();
        try {
        	m.validateCustomerDetails(name, date, type);
        	String s=m.getBookingConfirmation();
        	System.out.println(s);
        	
        }
        catch (InvalidCustomerDetailsException e) {
			// TODO: handle exception
        	System.out.println(e.getMessage());
		}
    }
}