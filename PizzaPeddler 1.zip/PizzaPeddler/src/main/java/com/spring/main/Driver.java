package com.spring.main;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.spring.config.ApplicationConfig;
import com.spring.exception.NoProfitException;
import com.spring.model.PizzaFranchise;
import com.spring.service.PizzaService;

public class Driver {

	public static void main(String[] args) {
		//Fill the code
		Scanner sc = new Scanner(System.in);
		ApplicationContext cn=new AnnotationConfigApplicationContext(ApplicationConfig.class);
		PizzaService ps = cn.getBean(PizzaService.class);
		PizzaFranchise pf = cn.getBean(PizzaFranchise.class);
		List<String> list = new ArrayList<>();
		
		for(int i=1;i<3;i++) {
			System.out.println("Pizza Peddler Franchise "+i+" details");
			System.out.println("Enter the location:");
			String location = sc.nextLine();
			System.out.println("Enter the total income:");
			double totalIncome = Double.parseDouble(sc.nextLine());
			System.out.println("Enter total expense amount for employee salary:");
			double empSal = Double.parseDouble(sc.nextLine());
			pf.setLocation(location);
			pf.setTotalIncome(totalIncome);
			pf.setEmployeeSalary(empSal);
			
			try {
				ps.calculateNetProfit(pf);
				list.add("Pizza Peddler at "+pf.getLocation()+" franchise Amount is $"+pf.getFranchiseAmount());
			}
			catch (NoProfitException e){
				list.add(e.getMessage());
			}
			
		}
		list.forEach(System.out::println);
	}

}
