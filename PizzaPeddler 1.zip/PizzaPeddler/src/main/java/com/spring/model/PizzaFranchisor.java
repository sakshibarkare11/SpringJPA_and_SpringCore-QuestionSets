package com.spring.model;

public interface PizzaFranchisor {
	  
 void calculateFranchiseAmount(double netProfit);
 
}
