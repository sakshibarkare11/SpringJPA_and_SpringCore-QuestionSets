package com.spring.model;

import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

//pojo class with required attributes,getters and setters 
//use appropriate annotation to make this class as component class
@Component
@Scope("prototype")
public class PizzaFranchise implements PizzaFranchisor {
	private String location;
	private double totalIncome;	
	private double employeeSalary;	
	private double franchiseAmount;
	//use appropriate annotation
	@Value("#{${percentage}}")
	private double percentage;
	//use appropriate annotation
	@Value("#{${commonExpenses.map}}")
	private Map<String, Double> commonExpenses;	
	public PizzaFranchise() {
		
	}
	public PizzaFranchise(double percentage, Map<String, Double> commonExpenses) {
		super();
		this.percentage = percentage;
		this.commonExpenses = commonExpenses;
	}


	public void setPercentage(double percentage) {
		this.percentage = percentage;
	}

	public double getPercentage() {
		return percentage;
	}

	

	public double getFranchiseAmount() {
		return franchiseAmount;
	}


	public Map<String, Double> getCommonExpenses() {
		return commonExpenses;
	}


	public void setCommonExpenses(Map<String, Double> commonExpenses) {
		this.commonExpenses = commonExpenses;
	}


	public void setFranchiseAmount(double franchiseAmount) {
		this.franchiseAmount = franchiseAmount;
	}


	public String getLocation() {
		return location;
	}


	public void setLocation(String location) {
		this.location = location;
	}


	public double getTotalIncome() {
		return totalIncome;
	}


	public void setTotalIncome(double totalIncome) {
		this.totalIncome = totalIncome;
	}


	public double getEmployeeSalary() {
		return employeeSalary;
	}


	public void setEmployeeSalary(double employeeSalary) {
		this.employeeSalary = employeeSalary;
	}


	public void calculateFranchiseAmount(double netProfit) {
		//Fill the code
		franchiseAmount=netProfit*percentage/100;
	}
}
