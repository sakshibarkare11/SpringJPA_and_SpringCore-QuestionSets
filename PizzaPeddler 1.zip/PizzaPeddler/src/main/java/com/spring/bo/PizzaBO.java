package com.spring.bo;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.spring.model.PizzaFranchise;

//use appropriate annotation to make this class as component class
@Component
public class PizzaBO {

	public double calculateNetProfit(PizzaFranchise franchise) {
		double expense=franchise.getEmployeeSalary();
		double totalIncome = franchise.getTotalIncome();
		double netProfit =0.0;
		//fill the code
	//	for(Map.Entry<String, Double> mm: franchise.getCommonExpenses().entrySet())
		for(Map.Entry<String, Double> entry : franchise.getCommonExpenses().entrySet()){
			expense = expense+entry.getValue();
		}
		
		netProfit = totalIncome-expense;
		return netProfit;
	}
}
