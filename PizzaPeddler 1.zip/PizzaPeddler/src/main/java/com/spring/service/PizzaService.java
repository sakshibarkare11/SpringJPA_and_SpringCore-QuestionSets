package com.spring.service;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;

import com.spring.bo.PizzaBO;
import com.spring.exception.NoProfitException;
import com.spring.model.PizzaFranchise;

//use appropriate annotation to make this class as component class
@Component
public class PizzaService {

	private PizzaBO pizzaBO;

	
	public PizzaBO getPizzaBO() {
		return pizzaBO;
	}

	public void setPizzaBO(PizzaBO pizzaBO) {
		this.pizzaBO = pizzaBO;
	}
	public void calculateNetProfit(PizzaFranchise franchise) throws NoProfitException {
		
		double netprofit= pizzaBO.calculateNetProfit(franchise);
		if(netprofit<=0) {
			throw new NoProfitException("No profit to calculate franchise amount");
		}
		franchise.calculateFranchiseAmount(netprofit);
		//Fill the code
	}
	//Use appropriate annotation
	@Autowired
	public PizzaService(PizzaBO pizzaBO) {
		
		this.pizzaBO = pizzaBO;
	}

	
	
}
