package com.spring.bo;

import com.spring.model.CookingClass;

//use appropriate annotation to make this class as component class

public class CookingBO {

	public static double calculateNetProfit(CookingClass cookingClassObj) {
		// FILL THE CODE HERE

		double ing = 0.0;

		return 0;
	}
}
