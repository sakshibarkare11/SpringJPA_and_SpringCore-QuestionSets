package com.spring.model;

import java.util.Map;

//pojo class with required attributes,getters and setters 
//use appropriate annotation to make this class as component class and use appropriate annotation for scope

public class CookingClass implements CookingSchool {

    private String cuisineType;
    private int noOfStudents;
    private double cuisineFee;
    private double instructorCommission;
    // use appropriate annotation
    private Map<String, Double> commonExpenses;
    // use appropriate annotation
    private double percentage;

    public CookingClass() {
        super();
    }

   	public String getCuisineType() {
		return cuisineType;
	}

	public void setCuisineType(String cuisineType) {
		this.cuisineType = cuisineType;
	}


	public int getNoOfStudents() {
		return noOfStudents;
	}


	public void setNoOfStudents(int noOfStudents) {
		this.noOfStudents = noOfStudents;
	}


	public double getCuisineFee() {
		return cuisineFee;
	}


	public void setCuisineFee(double cuisineFee) {
		this.cuisineFee = cuisineFee;
	}


	public double getInstructorCommission() {
		return instructorCommission;
	}

	public void setInstructorCommission(double instructorCommission) {
		this.instructorCommission = instructorCommission;
	}

	public Map<String, Double> getCommonExpenses() {
		return commonExpenses;
	}


	public void setCommonExpenses(Map<String, Double> commonExpenses) {
		this.commonExpenses = commonExpenses;
	}


	public double getPercentage() {
		return percentage;
	}


	public void setPercentage(double percentage) {
		this.percentage = percentage;
	}


	public void calculateInstructorCommission(double netProfit) {
		// FILL THE CODE HERE
		
	}

}
