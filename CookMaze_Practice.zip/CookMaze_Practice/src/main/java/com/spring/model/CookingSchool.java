package com.spring.model;

public interface CookingSchool {

  void calculateInstructorCommission(double netProfit) ;
}
