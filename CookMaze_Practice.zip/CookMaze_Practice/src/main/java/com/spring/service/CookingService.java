package com.spring.service;

import com.spring.bo.CookingBO;
import com.spring.model.CookingClass;

//use appropriate annotation to make this class as component class
public class CookingService {

	private CookingBO cookingBO;

	// use appropriate annotation
	public CookingService(CookingBO cookingBO) {
		super();
		this.cookingBO = cookingBO;
	}

	public CookingBO getCookingBO() {
		return cookingBO;
	}

	public void setCookingBO(CookingBO cookingBO) {
		this.cookingBO = cookingBO;
	}

	public void calculateNetProfit(CookingClass cookingClassObj) {
		// fill the code

	}
}