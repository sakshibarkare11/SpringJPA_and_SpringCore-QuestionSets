package com.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entities.Car;
import com.exception.InvalidRideException;
import com.exception.InvalidCarException;

import com.repository.RideRepository;
import com.repository.CarRepository;

@Service
public class CarServiceImpl implements ICarService {

	// Provide necessary Annotation
	@Autowired
	private CarRepository carRepository;

	@Override
	public Car addCar(Car car) {
		// fill code
	Car save = carRepository.save(car);
		return save;
	}
	
	@Override
	public Car appendDailyRentalRate(String carId, double incrementRent) throws InvalidCarException {
	    	// fill code
		Car car = carRepository.findById(carId).orElseThrow(()-> new InvalidCarException());
		car.setDailyRentalRate(car.getDailyRentalRate()+incrementRent);
		Car save = carRepository.save(car);
		return save;
	}

	@Override
	public Car viewCarById(String carId) throws InvalidCarException {
		// fill code
		Car car = carRepository.findById(carId).orElseThrow(()-> new InvalidCarException());
		return car;
	}

	@Override
	public List<Car> viewCarsBySeatingAndTransmission(int seatingCapacity, String transmissionType) {
		// fill code	
	 List<Car> list = carRepository.findBySeatingAndTransmission(seatingCapacity,transmissionType);
		
		return list;
	}
	
	@Override
	public Map<String, Double> getTotalDistanceCarwise() {
        // fill code	
		List<Object[]> carwise = carRepository.findByTotalDistanceCarwise();
		Map<String, Double> map= new HashMap<>();
		for (Object[] objects : carwise) {
			
			String id= (String) objects[0];
			Double sum= (Double) objects[1];
			map.put(id, sum);
		}
		return map;
	}
}
