package com.service;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;

import com.entities.Ride;
import com.exception.InvalidCarException;
import com.exception.InvalidRideException;

public interface IRideService {
	
	public Ride addRide(Ride ride, String carId) throws InvalidCarException;
	public Ride updatePickupLocation(String rideId, String pickupLocation) throws InvalidRideException;
	public List<Ride> viewRidesByDistance(double distance);
	public List<Ride> viewRidesByLicencePlateNumber(String licencePlateNumber );
	public Ride cancelRide (String rideId) throws InvalidRideException;
}
