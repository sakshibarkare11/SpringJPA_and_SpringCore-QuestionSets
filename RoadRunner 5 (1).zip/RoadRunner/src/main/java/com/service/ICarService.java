package com.service;

import java.util.List;
import java.util.Map;

import com.entities.Car;
import com.exception.InvalidCarException;

public interface ICarService {
    
	public Car addCar(Car car);
	public Car appendDailyRentalRate(String carId, double incrementRent) throws InvalidCarException;
	public Car viewCarById (String carId ) throws InvalidCarException ;
	public List<Car> viewCarsBySeatingAndTransmission(int seatingCapacity, String transmissionType);
	public Map<String,Double> getTotalDistanceCarwise();
}
