package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entities.Car;
import com.entities.Ride;
import com.exception.InvalidCarException;
import com.exception.InvalidRideException;
import com.repository.CarRepository;
import com.repository.RideRepository;

@Service
public class RideServiceImpl implements IRideService {

	// Provide necessary Annotation
	@Autowired
	private RideRepository rideRepository;
	
	// Provide necessary Annotation
	@Autowired
	private CarRepository carRepository;

	@Override
	public Ride addRide(Ride ride, String carId) throws InvalidCarException {
		// fill code
		Car car = carRepository.findById(carId).orElseThrow(()-> new InvalidCarException());
		ride.setCarObj(car);
		Ride save = rideRepository.save(ride);
		
		return save;
	}

	@Override
	public Ride updatePickupLocation(String rideId, String pickupLocation) throws InvalidRideException {		
		// fill code
		Ride ride = rideRepository.findById(rideId).orElseThrow(()-> new InvalidRideException());
		ride.setPickupLocation(pickupLocation);
		Ride save = rideRepository.save(ride);
		
		return save;
	}

	@Override
	public List<Ride> viewRidesByDistance(double distance) {
	    // fill code
		List<Ride> list = rideRepository.findbyviewRidesByDistance(distance);
	    
		return list;
	}

	@Override
	public List<Ride> viewRidesByLicencePlateNumber(String licencePlateNumber) {
		// fill code
		List<Ride> number = rideRepository.findByLicencePlateNumber(licencePlateNumber);
		
		
		return number;
	}

	@Override
	public Ride cancelRide(String rideId) throws InvalidRideException {
		// fill code
		Ride ride = rideRepository.findById(rideId).orElseThrow(()-> new InvalidRideException());
		rideRepository.delete(ride);
		
		return ride;
	}

}
