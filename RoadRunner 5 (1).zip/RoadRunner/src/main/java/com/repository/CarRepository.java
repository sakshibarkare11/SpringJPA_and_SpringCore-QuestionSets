package com.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.entities.Car;

//import jakarta.validation.constraints.AssertFalse.List;

//Provide necessary annotation
@Repository
public interface CarRepository  extends JpaRepository<Car, String>{

//	@Query(value = "select * from car c where  c.c.licence_plate_number =?1",nativeQuery = true)
//	List<Car> findBySeatingAndTransmission(int c, String transmissionType);

	
	
	@Query(value = "select c.car_id, sum(r.distance) from car c join ride r using(car_id) group by c.car_id order by c.car_id",nativeQuery = true)
	List<Object[]> findByTotalDistanceCarwise();
@Query(value = "select * from car c where c.seating_capacity =?1 and c.transmission_type =?2",nativeQuery = true)
	List<Car> findBySeatingAndTransmission(int seatingCapacity, String transmissionType);
	

	//Provide necessary methods to  view Car by seatingCapacity and transmissionType and to get the total distance carwise

}
