package com.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.entities.Ride;

//import jakarta.validation.constraints.AssertFalse.List;

//Provide necessary annotation
@Repository
public interface RideRepository extends JpaRepository<Ride, String>{

//	@Query(value = "select * from ride where r.distance >= ?1",nativeQuery = true)
@Query("select r from Ride r where r.distance >= ?1")
	List<Ride> findbyviewRidesByDistance(double distance);

	@Query("select r from Ride r where r.carObj.licencePlateNumber= ?1")
	List<Ride> findByLicencePlateNumber(String licencePlateNumber);

	// Provide necessary methods to view rides by distance and licence plate number

}
