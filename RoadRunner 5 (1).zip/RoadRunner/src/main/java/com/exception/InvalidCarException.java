package com.exception;

public class InvalidCarException extends Exception  {


}
