package com.exception;

public class InvalidRideException extends Exception {


    
}
