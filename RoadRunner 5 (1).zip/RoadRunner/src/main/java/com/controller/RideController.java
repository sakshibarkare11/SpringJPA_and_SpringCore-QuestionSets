package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.entities.Ride;
import com.exception.InvalidCarException;
import com.exception.InvalidRideException;
import com.service.IRideService;

import jakarta.validation.Valid;


//Provide necessary Annotation
@RestController
public class RideController {

	// Provide necessary Annotation
	@Autowired
	private IRideService rideService;

	// Provide necessary Annotation for the below methods and fill the code
	@PostMapping("/addRide/{carId}")
	public ResponseEntity<Ride> addRide(@Valid  @RequestBody Ride ride,@PathVariable String carId) throws InvalidCarException{
	    // fill code
		Ride ride2 = rideService.addRide(ride, carId);
		return ResponseEntity.status(200).body(ride2);
	}
@PutMapping("/updatePickupLocation/{rideId}/{pickupLocation}")
	public ResponseEntity<Ride> updatePickupLocation(@PathVariable String rideId,@PathVariable String pickupLocation) throws InvalidRideException {
	   	// fill code
	Ride location = rideService.updatePickupLocation(rideId, pickupLocation);
		return ResponseEntity.status(200).body(location);
	}
	@GetMapping("/viewRidesByDistance/{distance}")
	public ResponseEntity<List<Ride>> viewRidesByDistance(@PathVariable double distance) {
	    // fill code
		List<Ride> byDistance = rideService.viewRidesByDistance(distance);
		return ResponseEntity.status(200).body(byDistance);
	}
@GetMapping("/viewRidesByLicencePlateNumber/{licencePlateNumber}")
	public ResponseEntity<List<Ride>> viewRidesByLicencePlateNumber(@PathVariable String licencePlateNumber) {
	   	// fill code
	List<Ride> number = rideService.viewRidesByLicencePlateNumber(licencePlateNumber);
		return ResponseEntity.status(200).body(number);
	}

@DeleteMapping("/cancelRide/{rideId}")
	public ResponseEntity<Ride> cancelRide(@PathVariable String rideId) throws InvalidRideException {
	   	// fill code
	Ride cancelRide = rideService.cancelRide(rideId);
		return ResponseEntity.status(200).body(cancelRide);
	}

}
