package com.controller;

import java.util.List;
import java.util.Map;

import com.entities.Car;
import com.exception.InvalidCarException;
import com.exception.InvalidRideException;
import com.service.ICarService;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


//Provide necessary Annotation
@RestController
public class CarController {

	// Provide necessary Annotation
	@Autowired
	private ICarService carService;

	// Provide necessary Annotation for the below methods and fill the code
	@PostMapping("/addCar")
	public ResponseEntity<Car> addCar(@Valid @RequestBody Car car) throws InvalidCarException {
	    // fill code
		Car c= carService.addCar(car);
		return ResponseEntity.status(200).body(c);
	}
	@PutMapping("/appendDailyRentalRate/{carId}/{incrementRent}")
	public ResponseEntity<Car> appendDailyRentalRate(@PathVariable String carId,@PathVariable  double incrementRent) throws InvalidCarException {
	    // fill code
		Car rate = carService.appendDailyRentalRate(carId, incrementRent);
		return ResponseEntity.status(200).body(rate);
	}

@GetMapping("/viewCarById/{carId}")
	public ResponseEntity<Car> viewCarById(@PathVariable String carId) throws InvalidCarException {
	    // fill code
	Car id = carService.viewCarById(carId);
		return  ResponseEntity.status(200).body(id);
	}

@GetMapping("/viewCarsBySeatingAndTransmission/{seatingCapacity}/{transmissionType}")
	public ResponseEntity<List<Car>> viewCarsBySeatingAndTransmission(@PathVariable int seatingCapacity,@PathVariable String transmissionType) {
	    // fill code
		List<Car> list = carService.viewCarsBySeatingAndTransmission(seatingCapacity, transmissionType);
		return ResponseEntity.status(200).body(list);
	}
	@GetMapping("/getTotalDistanceCarwise")
	public ResponseEntity<Map<String,Double>> getTotalDistanceCarwise() {
	    // fill code
		Map<String,Double> map = carService.getTotalDistanceCarwise();
		return ResponseEntity.status(200).body(map);
	}
}
