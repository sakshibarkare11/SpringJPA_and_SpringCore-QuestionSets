package com.entities;

import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

//Provide necessary Annotation 
@Entity
@Getter
@Setter
@AllArgsConstructor
public class Ride {

	// Provide necessary Annotation
	@Id
	private String rideId;
	@NotEmpty(message = "Provide value for Customer Contact Number")
	private String customerContactNumber;
	@Min(value = 1,message = "Distance should be greater than zero")
	private double distance;

	private LocalDate rideDate;
	@NotEmpty(message = "Provide value for Pickup Location")
	private String pickupLocation;
	@NotEmpty(message = "Provide value for Droppff Location")
	private String dropoffLocation;
	@Min(value = 1,message = "Total cost should be greater than zero")
	private double totalCost;
	@NotEmpty(message = "Provide value for Payment Method")
	private String paymentMethod;

	// Provide necessary Annotations
	@ManyToOne
	@JoinColumn(name = "car_id")
	private Car carObj;
	
	public Ride() {
		super();
	}
	
}
