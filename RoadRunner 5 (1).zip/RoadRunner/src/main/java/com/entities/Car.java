package com.entities;

//import java.util.Date;
import java.util.List;

import org.hibernate.validator.constraints.Range;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

//Provide necessary Annotation
@Entity
@Getter
@Setter
@AllArgsConstructor
public class Car {

	// Provide necessary Annotation
	@Id
	private String carId;
	@NotEmpty(message = "Provide value for model")
	private String model;
	@NotEmpty(message = "Provide value for licence plate Number")
	private String licencePlateNumber;
	@NotEmpty(message = "Provide value for Transmission Type")
	private String transmissionType ;
	@NotEmpty(message = "Provide value for Fuel Type")
	private String fuelType;
    @Min(value = 5,message = "Seating capacity should be greater than or equal to 5")
	private int seatingCapacity;
    @Min(value = 1, message = "Daily rental rate should be greater than zero")
	private double dailyRentalRate ;
    @Max(value = 4,message = "Rating should be less than 5")
	private double rating ;
	
	// Provide necessary Annotations
	@OneToMany(mappedBy = "carObj")	
	private List<Ride> rideList;

	public Car() {
		super();
	}
	

}
