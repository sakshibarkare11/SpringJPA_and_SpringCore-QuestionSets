package com.exception;

public class InvalidMembershipException extends Exception  {
 
}
