package com.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.model.Membership;

//Provide necessary annotation
@Repository
public interface MembershipRepository extends JpaRepository<Membership, String>{

//	@Query(value = "select m from membership m where m.benefits =?1", nativeQuery = true)
	List<Membership> findByBenefitsContaining(String benefits);
	
	//@Query(value = "select m from membership m where m.membership_type =?1 and m.monthly_access_hours =?2", nativeQuery = true)
	List<Membership> findByMembershipTypeAndMonthlyAccessHoursGreaterThan(String membershipType, int monthlyAccessHours);
//   
	 // Provide necessary methods to view memberships by benefit, view memberships by membership type and monthly access hours and get membership count for each type
    
}