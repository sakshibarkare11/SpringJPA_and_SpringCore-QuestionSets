package com.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exception.InvalidMembershipException;
import com.model.Membership;
import com.repository.MembershipRepository;

//Provide necessary annotation
@Service
public class MembershipServiceImpl implements IMembershipService{
	
	//Provide necessary annotation
	@Autowired
	private MembershipRepository membershipRepo;

	public Membership addMembership(Membership membership) {
		Membership m1 = membershipRepo.save(membership);
		// fill the code
		return m1;
	}

	public Membership viewMembershipById(String membershipId) throws InvalidMembershipException {
		Membership id1 = membershipRepo.findById(membershipId).orElseThrow(() -> new  InvalidMembershipException());
		// fill the code
		return id1;
	}
	
	public List<Membership> viewMembershipsByBenefit(String benefit) {
		List<Membership> benefit1 = membershipRepo.findByBenefitsContaining(benefit);
		// fill the code
		return benefit1;
	} 

	public List<Membership> viewMembershipsByTypeAndAccessHours(String membershipType, int monthlyAccessHours) {
	List<Membership> list1 = membershipRepo.findByMembershipTypeAndMonthlyAccessHoursGreaterThan(membershipType, monthlyAccessHours);
		// fill the code
		return list1;
	} 	  	      	 	    	      	    	      	 	
	
	public Map<String,Integer> getMembershipCountTypeWise() {
		List<Membership> men = membershipRepo.findAll();
		Map<String, Integer> map = new HashMap<String, Integer>();
		for(Membership membership : men) {
			String membershipType = membership.getMembershipType();
			if(map.containsKey(membershipType)) {
				map.put(membershipType, map.get(membershipType)+1);
			}else {
				map.put(membershipType, 1);
			}
		}
		
		// fill the code
		return map;
	}

}
