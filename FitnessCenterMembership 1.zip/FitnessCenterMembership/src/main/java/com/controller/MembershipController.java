package com.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.exception.InvalidMembershipException;
import com.model.Membership;
import com.service.IMembershipService;

import jakarta.validation.Valid;

//Provide necessary Annotation
@RestController
public class MembershipController {
	
	//Provide necessary Annotation
	@Autowired
	private IMembershipService membershipService;
	
	//Provide necessary Annotation for the below methods and fill the code
	
	@PostMapping("/addMembership")
	public ResponseEntity<Membership> addMembership(@Valid @RequestBody Membership membership) {
		Membership m = membershipService.addMembership(membership);
		return ResponseEntity.status(200).body(m);
	}	 	  	      	 	    	      	    	      	 	

	@GetMapping("/viewMembershipById/{membershipId}")
	public ResponseEntity<Membership> viewMembershipById(@PathVariable String membershipId) throws InvalidMembershipException{
		Membership id = membershipService.viewMembershipById(membershipId);
		return ResponseEntity.status(200).body(id);
	}
	
	@GetMapping("/viewMembershipsByBenefit/{benefit}")
	public ResponseEntity<List<Membership>> viewMembershipsByBenefit(@PathVariable String benefit) {
		List<Membership> benifit = membershipService.viewMembershipsByBenefit(benefit);
		return ResponseEntity.status(200).body(benifit);
	}
	
	@GetMapping("/viewMembershipsByTypeAndAccessHours/{membershipType}/{monthlyAccessHours}")
	public ResponseEntity<List<Membership>> viewMembershipsByTypeAndAccessHours(@PathVariable String membershipType,@PathVariable int monthlyAccessHours) {
		List<Membership> type = membershipService.viewMembershipsByTypeAndAccessHours(membershipType, monthlyAccessHours);
		return ResponseEntity.status(200).body(type);
	}
	
	@GetMapping("/getMembershipCountTypeWise")
	public ResponseEntity<Map<String,Integer>> getMembershipCountTypeWise() {
		Map<String,Integer> count = membershipService.getMembershipCountTypeWise();
		return ResponseEntity.status(200).body(count);
	}
}